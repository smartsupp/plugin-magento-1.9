<?php
/**
 * @author Tomáš Blatný
 */

use Magento\Framework\Component\ComponentRegistrar;

ComponentRegistrar::register(ComponentRegistrar::MODULE, 'Smartsupp_Smartsupp', __DIR__);
